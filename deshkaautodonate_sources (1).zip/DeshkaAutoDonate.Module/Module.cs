using PlayerRoles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Deshka.API.Abstract;
using Deshka.API.NetworkTools;
using Deshka.API.Other;
using DeshkaAutoDonate.Module.Models;
using Fleck;
using LabApi.Features.Wrappers;

namespace DeshkaAutoDonate.Module
{
    public class Module : Module<DefaultSubmoduleSystem, Config>
    {
        public override string Name => "DeshkaAutoDonate.Module";
        public override string Prefix => Name;
        public override List<Submodule> Submodules { get; } = new List<Submodule>();

        private static readonly Dictionary<byte, RoleData> RoleDatas = new Dictionary<byte, RoleData>();
        public static Module Instance { get; private set; }

        private WebSocketServer _server;        public static HashSet<string> LastRoundScpDonators { get; set; } = new HashSet<string>();        public static HashSet<string> CurrentRoundScpDonators { get; set; } = new HashSet<string>();

        public static Dictionary<RoleTypeId, string> ReservedScps { get; set; } = new Dictionary<RoleTypeId, string>();        public static bool QueueProcessed { get; set; } = false;        public static HashSet<RoleTypeId> RoundStartAssignedScps { get; set; } = new HashSet<RoleTypeId>();

        protected override void OnEnabling()
        {
            EventHandlers.RegisterHandlers();
            Logger?.Info("DeshkaAutoDonate.Module enabled, handlers registered.");

            Instance = this;

            RoleDatas.Add(0, new RoleData());

            foreach (RoleData role in Config.Roles)
            {
                Logger?.Debug($"Role id: {role.Id}, config name: {role.ConfigName}");

                if (RoleDatas.TryGetValue(role.Id, out RoleData data))
                {
                    Logger?.Warn($"Key {role.Id} already found in dictionary, value group: {data.ConfigName}");
                    continue;
                }

                RoleDatas.Add(role.Id, role);
                CreateOrLoad(role.Id);
            }

            foreach (DonatorData donator in LoadAll())
            {
                if (!donator.Suspended) continue;
                if (donator.SuspendExpires > DateTime.UtcNow) continue;

                donator.Suspended = false;
                Update(donator);
            }

            StartWebSocketServer();
        }

        protected override void OnDisabling()
        {
            List<DonatorData> donatorDatas = LoadAll();
            foreach (DonatorData data in donatorDatas)
                if (data.ExpiringTime < DateTime.UtcNow)
                    Remove(data);

            _server?.Dispose();
            _server = null;

            Instance = null;
            EventHandlers.UnregisterHandlers();
        }

        private void StartWebSocketServer()
        {
            try
            {
                _server = new WebSocketServer($"ws://0.0.0.0:{Config.WebSocketPort}");

                _server.Start(socket =>
                {
                    socket.OnOpen = () =>
                    {
                        Logger?.Info("Клиент подключен");
                    };

                    socket.OnClose = () =>
                    {
                        Logger?.Info("Клиент отключен");
                    };

                    socket.OnError = ex =>
                    {
                        Logger?.Error($"Ошибка {ex.Message}");
                    };

                    Action<byte[]> handleData = data =>
                    {
                        try
                        {
                            if (data.Length < 1) return;

                            
                            if (data[0] == 255)
                            {
                                if (data.Length >= 5)
                                {
                                    ushort port = (ushort)BitConverter.ToInt32(data, 1);
                                    Logger?.Info($"Клиент подключен на порту {port}");
                                }
                                return;
                            }

                            if (data.Length < 4) return;

                            int length = BitConverter.ToInt32(data, 0);
                            if (length <= 0 || length > data.Length - 4) return;

                            byte[] msgData = new byte[length];
                            Buffer.BlockCopy(data, 4, msgData, 0, length);

                            string resp = ProcessMessage(msgData, length);

                            byte[] respBytes = Encoding.UTF8.GetBytes(resp);
                            byte[] respLen = BitConverter.GetBytes(respBytes.Length);
                            byte[] packet = new byte[respLen.Length + respBytes.Length];
                            Buffer.BlockCopy(respLen, 0, packet, 0, respLen.Length);
                            Buffer.BlockCopy(respBytes, 0, packet, respLen.Length, respBytes.Length);

                            socket.Send(packet);
                        }
                        catch (Exception ex)
                        {
                            Logger?.Error($"Ошибка обрабо.ки сообщения {ex.Message}");
                        }
                    };

                    socket.OnBinary = handleData;
                    socket.OnMessage = text =>
                    {
                        
                        handleData(Encoding.UTF8.GetBytes(text));
                    };
                });

                Logger?.Info($"WebSocket запущен ws://0.0.0.0:{Config.WebSocketPort}");
            }
            catch (Exception ex)
            {
                Logger?.Error($"Не удалось запустить WebSocket {ex.Message}");
            }
        }

        public static DonatorData Load(string steamId)
        {
            if (!steamId.EndsWith("@steam")) return null;
            steamId = steamId.Replace("@steam", string.Empty);
            ulong steamIdRaw = ulong.Parse(steamId);
            return Instance.DataStorage?.GetData<DonatorData>(d => d.SteamId == steamIdRaw);
        }

        public static List<DonatorData> LoadAll()
        {
            return Instance.DataStorage?.GetAllData<DonatorData>().ToList() ?? new List<DonatorData>();
        }

        public static bool Update(DonatorData data)
        {
            return Instance.DataStorage?.UpdateData<DonatorData>(data) ?? false;
        }

        public static bool Remove(DonatorData data)
        {
            return Instance.DataStorage?.DeleteData<DonatorData>(data.Id) ?? false;
        }

        public static void Add(DonatorData data)
        {
            Instance.DataStorage?.InsertData<DonatorData>(data);
        }

        public static CodeData LoadCode(string code)
        {
            return Instance.DataStorage?.GetData<CodeData>(d => d.Code == code);
        }

        public static void Add(CodeData data)
        {
            Instance.DataStorage?.InsertData<CodeData>(data);
        }

        public static bool Remove(CodeData data)
        {
            return Instance.DataStorage?.DeleteData<CodeData>(data.Id) ?? false;
        }

        public static QueueData Load(byte roleId)
        {
            return Instance.DataStorage?.GetData<QueueData>(d => d.RoleId == roleId);
        }

        public static QueueData CreateOrLoad(byte roleId)
        {
            QueueData data = Load(roleId);
            if (data == null)
            {
                data = new QueueData
                {
                    Queue = new SimpleQueue<QueueElement>(),
                    RoleId = roleId
                };
                Add(data);
                return Load(roleId);
            }
            return data;
        }

        public static bool Update(QueueData data)
        {
            return Instance.DataStorage?.UpdateData<QueueData>(data) ?? false;
        }

        public static void Add(QueueData data)
        {
            Instance.DataStorage?.InsertData(data);
        }

        public static RoleData GetRoleById(byte id)
        {
            return RoleDatas[id];
        }

        public static List<RoleData> GetRoles()
        {
            return RoleDatas.Select(kvp => kvp.Value).ToList();
        }

        private static string ProcessMessage(byte[] msg, int length)
        {
            if (length < 1) return "INVALID MSG TYPE";

            var reader = NetworkObjectPool.RentReader(msg);
            byte msgType = reader.ReadByte();

            switch (msgType)
            {
                case 0:
                    {
                        string issuer = reader.ReadString();
                        byte groupId = reader.ReadByte();
                        int donateDays = reader.ReadInt32();

                        if (!RoleDatas.ContainsKey(groupId))
                            return $"Донат роль с айди {groupId} не найдена";

                        string code = CodeGen.GenerateCode();
                        Add(new CodeData
                        {
                            Code = code,
                            Issuer = issuer,
                            GroupId = groupId,
                            DonateDuration = donateDays
                        });

                        return $"Сгенерирован новый код: {code}";
                    }
                case 1:
                    {
                        string steamId = reader.ReadString();
                        long suspendExpiresTicks = reader.ReadInt64();
                        DateTime suspendExpires = new DateTime(suspendExpiresTicks);

                        DonatorData data = Load(steamId);
                        if (data == null) return "Указанный игрок не является донатером";

                        data.Suspended = true;
                        data.SuspendExpires = suspendExpires;

                        if (!Update(data)) return "Не удалось обновить информацию о донатере";
                        return "Донат успешно приостановлен";
                    }
                case 2:
                    {
                        string steamId = reader.ReadString();
                        DonatorData data = Load(steamId);
                        if (data == null) return "Указанный игрок не является донатером";
                        if (!Remove(data)) return "Не удалось обновить информацию о донатере";
                        return "Донат успешно снят";
                    }
                case 3:
                    {
                        List<DonatorData> donData = LoadAll();
                        StringBuilder sb = Pool<StringBuilder>.Rent();

                        sb.AppendLine("**Список донатеров:**");
                        foreach (DonatorData data in donData)
                        {
                            sb.AppendLine("--------------------------------");
                            sb.AppendLine($"SteamID: {data.SteamId}");
                            sb.AppendLine($"Donate ID: {data.GroupId}");
                            sb.AppendLine($"Suspended: {data.Suspended}");
                            if (data.Suspended)
                                sb.AppendLine($"Suspend End Date: {data.SuspendExpires.AddHours(3):dd.MM.yyyy HH:mm}");
                            sb.AppendLine($"Issuer: {data.Issuer}");
                            sb.AppendLine($"Issued: {data.IssuanceTime.AddHours(3):dd.MM.yyyy HH:mm}");
                            sb.AppendLine($"Expires: {data.ExpiringTime.AddHours(3):dd.MM.yyyy HH:mm}");
                            sb.AppendLine($"MTF Replace: {data.MtfReplace}");
                            sb.AppendLine($"Chaos Replace: {data.ChaosReplace}");
                            sb.AppendLine($"Rainbow Nick: {data.RainbowNickname}");
                            sb.AppendLine($"Unrecoverable: {data.UnrecoverableEnabled}");
                            if (data.Cosmetics.Count > 0)
                            {
                                sb.Append("Cosmetics: ");
                                sb.AppendLine(string.Join(", ", data.Cosmetics));
                            }
                        }

                        string text = sb.ToString().TrimEnd();
                        Pool<StringBuilder>.Return(sb);
                        return text;
                    }
                default:
                    return "INVALID MSG TYPE";
            }
        }
    }
}
