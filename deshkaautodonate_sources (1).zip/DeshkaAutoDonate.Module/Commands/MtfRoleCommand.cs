using System;
using System.Collections.Generic;
using System.Text;
using CommandSystem;
using Deshka.API.Helpers;
using Deshka.API.Other;
using DeshkaAutoDonate.Module.Models;
using LabApi.Features.Wrappers;
using PlayerRoles;

namespace DeshkaAutoDonate.Module.Commands
{
    [CommandHandler(typeof(ClientCommandHandler))]
    public class MtfRoleCommand : ICommand, IUsageProvider
    {
        public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
        {
            if (!Player.TryGet(sender, out Player player))
            {
                response = "Вы должны быть подключены к серверу для выполнения данной команды";
                return false;
            }

            DonatorData donatorData = Module.Load(player.UserId);

            if (donatorData == null)
            {
                response = "Вы должны быть донатером для выполнения данной команды";
                return false;
            }
            
            if (donatorData.Suspended)
            {
                if (donatorData.SuspendExpires <= DateTime.UtcNow)
                {
                    donatorData.Suspended = false;
                    Module.Update(donatorData);
                }
                else
                {
                    response =
                        $"Ваша донат-привелегия приостановлена до {donatorData.SuspendExpires.AddHours(3):dd.MM.yyyy HH:mm} (МСК)";
                    return false;
                }
            }

            RoleData roleData = Module.GetRoleById(donatorData.GroupId);

            List<RoleTypeId> mtfRoles = roleData.MtfChangeRoles;

            if (mtfRoles.Count == 0)
            {
                response = "В вашу донат привелегию не входит изменение роли при спавне МОГ";
                return false;
            }
            
            if (arguments.Count < 1)
            {
                StringBuilder sb = Pool<StringBuilder>.Rent();

                sb.AppendLine("Доступные роли:");
                sb.AppendLine("-1: Включить стандартный спавн");

                for (int i = 0; i < mtfRoles.Count; i++)
                    sb.AppendLine($"{i}: {mtfRoles[i].TranslateRoleType(true)}");

                response = $"\n{sb.ToString().TrimEnd()}";
                Pool<StringBuilder>.Return(sb);
                return false;
            }

            if (!int.TryParse(arguments.Array[1], out int roleId))
            {
                response = $"Айди роли должен быть числом в диапазоне от -1 до {mtfRoles.Count - 1}";
                return false;
            }

            if (roleId < -1 || roleId >= mtfRoles.Count)
            {
                response = "Айди который вы указали невалидный";
                return false;
            }

            if (roleId == -1)
            {
                if (donatorData.MtfReplace != RoleTypeId.None)
                {
                    donatorData.MtfReplace = RoleTypeId.None;
                    Module.Update(donatorData);
                }

                response = "Вы успешно убрали замену роли при спавне МОГ";
                return true;
            }

            RoleTypeId role = mtfRoles[roleId];

            if (donatorData.MtfReplace != role)
            {
                donatorData.MtfReplace = role;
                Module.Update(donatorData);
            }

            response = $"Вы успешно изменили роль при спавне МОГ на {role}";
            return true;
        }

        public string Command => "mtfrole";
        public string[] Aliases => null;
        public string Description => "Изменяет роль за которую вас гарантированно спавнит при спавне мог";
        public string[] Usage { get; } = { "Role ID" };
    }
}