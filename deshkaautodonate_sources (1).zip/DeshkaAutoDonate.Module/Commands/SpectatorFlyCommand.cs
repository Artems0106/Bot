using CommandSystem;
using DeshkaAutoDonate.Module.Models;
using LabApi.Features.Wrappers;
using System;

namespace DeshkaAutoDonate.Module.Commands
{
    [CommandHandler(typeof(ClientCommandHandler))]
    public class SpectatorFlyCommand : ICommand
    {
        public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
        {
            if (!Player.TryGet(sender, out Player player))
            {
                response = "Вы должны быть подключены к серверу для выполнения данной команды";
                return false;
            }

            if (!Round.IsRoundStarted)
            {
                response = "Данную команду можно использовать только во время раунда";
                return false;
            }

            if (player.IsAlive)
            {
                response = "Вы должны быть мёртвы для использования данной команды";
                return false;
            }

            DonatorData donatorData = Module.Load(player.UserId);

            if (donatorData == null)
            {
                response = "Вы должны быть донатером для выполнения данной команды";
                return false;
            }
            
            if (donatorData.Suspended)
            {
                if (donatorData.SuspendExpires <= DateTime.UtcNow)
                {
                    donatorData.Suspended = false;
                    Module.Update(donatorData);
                }
                else
                {
                    response =
                        $"Ваша донат-привелегия приостановлена до {donatorData.SuspendExpires.AddHours(3):dd.MM.yyyy HH:mm} (МСК)";
                    return false;
                }
            }
            
            RoleData roleData = Module.GetRoleById(donatorData.GroupId);

            if (!roleData.SpectatorFly)
            {
                response = "В вашу донат привелегию не входит полёт в спектаторах";
                return false;
            }
            
            return SpectatorFly.SwitchMode(player, out response);
        }

        public string Command => "spectatorfly";
        public string[] Aliases { get; } = { "specfly", "spectate" };
        public string Description => "Переключает режим полёта во время наблюдения за игроками";
    }
}