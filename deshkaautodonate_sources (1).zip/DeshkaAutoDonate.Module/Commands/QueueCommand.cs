using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommandSystem;
using DeshkaAutoDonate.Module.Models;
using LabApi.Features.Wrappers;
using PlayerRoles;

namespace DeshkaAutoDonate.Module.Commands
{
    [CommandHandler(typeof(ClientCommandHandler))]
    public class QueueCommand : ICommand
    {
        public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
        {
            if (!Player.TryGet(sender, out Player player))
            {
                response = "Вы должны быть подключены к серверу для выполнения данной команды";
                return false;
            }

            DonatorData donatorData = Module.Load(player.UserId);

            if (donatorData == null)
            {
                response = "Вы должны быть донатером для выполнения данной команды";
                return false;
            }

            if (donatorData.Suspended)
            {
                if (donatorData.SuspendExpires <= DateTime.UtcNow)
                {
                    donatorData.Suspended = false;
                    Module.Update(donatorData);
                }
                else
                {
                    response =
                        $"Ваша донат-привелегия приостановлена до {donatorData.SuspendExpires.AddHours(3):dd.MM.yyyy HH:mm} (МСК)";
                    return false;
                }
            }

            RoleData roleData = Module.GetRoleById(donatorData.GroupId);

            if (!roleData.Queue)
            {
                response = "В вашу донат привилегию не входит доступ к очереди";
                return false;
            }

            if (arguments.Count >= 1)
            {
                bool special = roleData.SpecialQueue;

                int onlineDonatorsWithQueue = 0;
                foreach (Player p in Player.List)
                {
                    DonatorData d = Module.Load(p.UserId);
                    if (d == null) continue;
                    RoleData rd = Module.GetRoleById(d.GroupId);
                    if (rd != null && rd.Queue)
                        onlineDonatorsWithQueue++;
                }

                if (onlineDonatorsWithQueue <= 1
                    && (Module.LastRoundScpDonators.Contains(player.UserId)
                        || Module.CurrentRoundScpDonators.Contains(player.UserId)))
                {
                    response = "Вы играли за SCP в этом или прошлом раунде. Подождите один раунд перед повторным использованием очереди.";
                    return false;
                }

                if (!special)
                {
                    response = "В вашу донат привилегию не входит доступ к специальной очереди";
                    return false;
                }

                RoleTypeId? role = RoleParser.Parse(arguments.Array[1], false, true);

                if (!role.HasValue)
                {
                    response = "Указанная роль не найдена";
                    return false;
                }

                QueueData queueData = Module.Load(roleData.Id);

                QueueElement lastInQueue = queueData.Queue.LastOrDefault();
                if (lastInQueue != null
                    && lastInQueue.Role != RoleTypeId.None
                    && lastInQueue.Role == role.Value)
                {
                    response = $"SCP {role.Value} уже стоит следующим в очереди. Выберите другой объект, чтобы они чередовались.";
                    return false;
                }

                QueueElement existing = queueData.Find(player.UserId);

                if (existing != null)
                {
                    if (existing.Role == role.Value)
                    {
                        response = $"Вы уже стоите в очереди за {role.Value}. Выберите другой объект.";
                        return false;
                    }

                    existing.Role = role.Value;
                    existing.Special = true;

                    Module.Update(queueData);

                    response = $"Вы успешно заменили желаемую роль (позиция: {queueData.Queue.ToList().FindIndex(e => e.UserId == player.UserId) + 1})";
                    return true;
                }

                QueueElement newElement = new QueueElement
                {
                    Role = role.Value,
                    Special = true,
                    UserId = player.UserId
                };

                queueData.Queue.Enqueue(newElement);

                Module.Update(queueData);

                response = $"Вы успешно встали в очередь (позиция: {queueData.Queue.Count})";
                return true;
            }

            QueueData data = Module.Load(roleData.Id);

            QueueElement element = data.Find(player.UserId);

            if (element != null)
            {
                if (element.Special && element.Role != RoleTypeId.None)
                {
                    element.Role = RoleTypeId.None;

                    Module.Update(data);

                    response = "Вы успешно изменили роль на случайную";
                    return true;
                }

                response = "Вы и так стоите в очереди";
                return false;
            }

            int onlineDonatorsWithQueue2 = 0;
            foreach (Player p in Player.List)
            {
                DonatorData d = Module.Load(p.UserId);
                if (d == null) continue;
                RoleData rd = Module.GetRoleById(d.GroupId);
                if (rd != null && rd.Queue)
                    onlineDonatorsWithQueue2++;
            }

            if (onlineDonatorsWithQueue2 <= 1
                && (Module.LastRoundScpDonators.Contains(player.UserId)
                    || Module.CurrentRoundScpDonators.Contains(player.UserId)))
            {
                response = "Вы играли за SCP в этом или прошлом раунде. Подождите один раунд перед повторным использованием очереди.";
                return false;
            }

            QueueElement newElem = new QueueElement
            {
                Role = RoleTypeId.None,
                Special = roleData.SpecialQueue,
                UserId = player.UserId
            };

            data.Queue.Enqueue(newElem);

            Module.Update(data);

            response = $"Вы успешно встали в очередь (позиция: {data.Queue.Count})";
            return true;
        }

        public string Command => "queue";
        public string[] Aliases => null;
        public string Description => "Позволяет встать в очередь на спавн за SCP";
    }
}
