using System;
using CommandSystem;
using DeshkaAutoDonate.Module.Models;
using LabApi.Features.Wrappers;

namespace DeshkaAutoDonate.Module.Commands
{
    [CommandHandler(typeof(ClientCommandHandler))]
    public class ActivateCommand : ICommand, IUsageProvider
    {
        public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
        {
            if (!Player.TryGet(sender, out Player player))
            {
                response = "Для выполнения данной команды вы должны быть подключены к серверу";
                return false;
            }
            
            if (arguments.Count < 1)
            {
                response = "Укажите код для активации";
                return false;
            }

            string steamId = player.UserId;

            if (!steamId.EndsWith("@steam"))
            {
                response = $"Для использования данной команды вы должны быть авторизированы через стим, ваш авторизатор: {steamId.Split('@')[1]}";
                return false;
            }
            
            DonatorData curData = Module.Load(player.UserId);

            if (curData != null && curData.GroupId != 0)
            {
                response = "У вас уже есть действующая привелегия, если вы хотите активировать новую то обратитесь к высшему составу сервера";
                return false;
            }

            CodeData codeData = Module.LoadCode(arguments.Array[1]);

            if (codeData == null)
            {
                response = "Указанный код не найден";
                return false;
            }

            DonatorData data = new DonatorData();

            if (curData != null)
            {
                // перенести все фичи по типу косметики на новую информацию
                data.Cosmetics = curData.Cosmetics;
                data.Suspended = curData.Suspended;
                data.SuspendExpires = curData.SuspendExpires;
                data.RainbowNickname = curData.RainbowNickname;
            }

            data.SteamId = ulong.Parse(steamId.Split('@')[0]);
            data.IssuanceTime = DateTime.UtcNow;
            data.GroupId = codeData.GroupId;
            data.ExpiringTime = DateTime.UtcNow.AddDays(codeData.DonateDuration);
            data.Issuer = codeData.Issuer;

            Module.Remove(codeData);
            
            Module.Add(data);
            
            response = "Код успешно активирован!";
            return true;
        }

        public string Command => "activate";
        public string[] Aliases { get; } = { "activatecode", "codeactivate" };
        public string Description => "Команда для активации кода от доната";
        public string[] Usage { get; } = { "Код" };
    }
}