using System;
using System.Collections.Generic;
using System.Text;
using CommandSystem;
using Deshka.API.Helpers;
using Deshka.API.Other;
using DeshkaAutoDonate.Module.Models;
using LabApi.Features.Wrappers;
using PlayerRoles;

namespace DeshkaAutoDonate.Module.Commands
{
    [CommandHandler(typeof(ClientCommandHandler))]
    public class ChaosRoleCommand : ICommand, IUsageProvider
    {
        public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
        {
            if (!Player.TryGet(sender, out Player player))
            {
                response = "Вы должны быть подключены к серверу для выполнения данной команды";
                return false;
            }

            DonatorData donatorData = Module.Load(player.UserId);

            if (donatorData == null)
            {
                response = "Вы должны быть донатером для выполнения данной команды";
                return false;
            }
            
            if (donatorData.Suspended)
            {
                if (donatorData.SuspendExpires <= DateTime.UtcNow)
                {
                    donatorData.Suspended = false;
                    Module.Update(donatorData);
                }
                else
                {
                    response =
                        $"Ваша донат-привелегия приостановлена до {donatorData.SuspendExpires.AddHours(3):dd.MM.yyyy HH:mm} (МСК)";
                    return false;
                }
            }
            
            RoleData roleData = Module.GetRoleById(donatorData.GroupId);

            List<RoleTypeId> chaosRoles = roleData.ChaosChangeRoles;

            if (chaosRoles.Count == 0)
            {
                response = "В вашу донат привелегию не входит изменение роли при спавне ПХ";
                return false;
            }
            
            if (arguments.Count < 1)
            {
                StringBuilder sb = Pool<StringBuilder>.Rent();

                sb.AppendLine("Доступные роли:");
                sb.AppendLine("-1: Включить стандартный спавн");

                for (int i = 0; i < chaosRoles.Count; i++)
                    sb.AppendLine($"{i}: {chaosRoles[i].TranslateRoleType(true)}");

                response = $"\n{sb.ToString().TrimEnd()}";
                Pool<StringBuilder>.Return(sb);
                return false;
            }

            if (!int.TryParse(arguments.Array[1], out int roleId))
            {
                response = $"Айди роли должен быть числом в диапазоне от -1 до {chaosRoles.Count - 1}";
                return false;
            }

            if (roleId < -1 || roleId >= chaosRoles.Count)
            {
                response = "Айди который вы указали невалидный";
                return false;
            }

            if (roleId == -1)
            {
                if (donatorData.ChaosReplace != RoleTypeId.None)
                {
                    donatorData.ChaosReplace = RoleTypeId.None;
                    Module.Update(donatorData);
                }

                response = "Вы успешно убрали замену роли при спавне ПХ";
                return true;
            }

            RoleTypeId role = chaosRoles[roleId];

            if (donatorData.ChaosReplace != role)
            {
                donatorData.ChaosReplace = role;
                Module.Update(donatorData);
            }

            response = $"Вы успешно изменили роль при спавне ПХ на {role}";
            return true;
        }

        public string Command => "chaosrole";
        public string[] Aliases { get; } = {"cirole"};
        public string Description => "Изменяет роль за которую вас гарантированно спавнит при спавне пх";
        public string[] Usage { get; } = { "Role ID" };
    }
}