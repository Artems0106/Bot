using System;
using System.Linq;
using CommandSystem;
using DeshkaAutoDonate.Module.Models;
using LabApi.Features.Wrappers;
using PlayerRoles;

namespace DeshkaAutoDonate.Module.Commands
{
    [CommandHandler(typeof(ClientCommandHandler))]
    public class ChangeRoleCommand : ICommand, IUsageProvider
    {
        private static readonly RoleTypeId[] AllowedRoles = {
            RoleTypeId.ClassD,
            RoleTypeId.Scientist,
            RoleTypeId.FacilityGuard
        };

        private const int MaxChangeTime = 30;

        public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
        {
            if (!Round.IsRoundStarted)
            {
                response = "Данную команду можно использовать только во время раунда";
                return false;
            }

            if (!Player.TryGet(sender, out Player player))
            {
                response = "Вы должны быть игроком для выполнения данной команды";
                return false;
            }

            if (arguments.Count < 1)
            {
                response = "Укажите роль для смены";
                return false;
            }

            DonatorData donatorData = Module.Load(player.UserId);

            if (donatorData == null)
            {
                response = "Данная команда доступна только донатерам";
                return false;
            }

            if (donatorData.Suspended)
            {
                if (donatorData.SuspendExpires <= DateTime.UtcNow)
                {
                    donatorData.Suspended = false;
                    Module.Update(donatorData);
                }
                else
                {
                    response =
                        $"Ваша донат-привелегия приостановлена до {donatorData.SuspendExpires.AddHours(3):dd.MM.yyyy HH:mm} (МСК)";
                    return false;
                }
            }

            string roleName = string.Join(" ", arguments.Array.Skip(1));

            RoleTypeId? role = RoleParser.Parse(roleName, true);

            if (role == null)
            {
                response = $"Роли {roleName} не существует";
                return false;
            }

            bool isAllowed = false;
            foreach (RoleTypeId allowed in AllowedRoles)
            {
                if (role.Value == allowed)
                {
                    isAllowed = true;
                    break;
                }
            }

            if (!isAllowed)
            {
                response = $"Вы можете сменить роль только на Дешку, Учёного или Охранника";
                return false;
            }

            if (Round.Duration.TotalSeconds > MaxChangeTime)
            {
                response = "Время для смены роли вышло (можно только в первые 30 секунд)";
                return false;
            }

            player.SetRole(role.Value, RoleChangeReason.Respawn);

            response = "Успешно!";
            return true;
        }

        public string Command => "changerole";
        public string[] Aliases { get; } = {"changer", "rolechange"};
        public string Description => "Меняет вашу роль в начале раунда на Дешку, Учёного или Охранника";
        public string[] Usage { get; } = {"Роль для смены"};
    }
}
