using System;
using CommandSystem;
using Deshka.API.Other;
using LabApi.Features.Wrappers;

namespace DeshkaAutoDonate.Module.Commands
{
    [CommandHandler(typeof(ClientCommandHandler))]
    public class VoicemuteCommand : ICommand
    {
        public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
        {
            if (!Player.TryGet(sender, out Player player))
            {
                response = "Вы должны быть подключены к серверу";
                return false;
            }

            if (!SpectatorFly.IsEnabled(player))
            {
                response = "Эта команда доступна только в режиме SpectatorFly";
                return false;
            }

            bool nowUnmuted = SpectatorFly.ToggleMute(player);
            SpectatorFly.ShowHint(player, !nowUnmuted);

            response = string.Empty;
            return true;
        }

        public string Command => "voicemute";
        public string[] Aliases { get; } = { "vmute" };
        public string Description => "Вкл/выкл звук от спектаторов в режиме SpectatorFly";
    }
}
