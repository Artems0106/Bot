using CommandSystem;
using DeshkaAutoDonate.Module.Models;
using LabApi.Features.Wrappers;
using System;

namespace DeshkaAutoDonate.Module.Commands
{
    [CommandHandler(typeof(ClientCommandHandler))]
    public class UnrecoverableCommand : ICommand
    {
        public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
        {
            if (!Player.TryGet(sender, out Player player))
            {
                response = "Вы должны быть подключены к серверу для выполнения данной команды";
                return false;
            }

            DonatorData donatorData = Module.Load(player.UserId);

            if (donatorData == null)
            {
                response = "Вы должны быть донатером для выполнения данной команды";
                return false;
            }
            
            if (donatorData.Suspended)
            {
                if (donatorData.SuspendExpires <= DateTime.UtcNow)
                {
                    donatorData.Suspended = false;
                    Module.Update(donatorData);
                }
                else
                {
                    response =
                        $"Ваша донат-привелегия приостановлена до {donatorData.SuspendExpires.AddHours(3):dd.MM.yyyy HH:mm} (МСК)";
                    return false;
                }
            }

            RoleData roleData = Module.GetRoleById(donatorData.GroupId);

            if (!roleData.Unrecoverable)
            {
                response = "В вашу донат привелегию не входит отключение возможности возрождения чумным доктором";
                return false;
            }

            bool newStatus = !donatorData.UnrecoverableEnabled;

            donatorData.UnrecoverableEnabled = newStatus;
            
            string statusText = newStatus ? "<color=#00FF00>НЕТ</color>" : "<color=#FF0000>ДА</color>";

            Module.Update(donatorData);

            response = $"Чумной доктор может вас возрождать: {statusText}";
            return true;
        }

        public string Command => "unrecoverable";
        public string[] Aliases => null;
        public string Description => "Переключает возможность возрождения вас чумным доктором";
    }
}