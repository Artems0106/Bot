﻿using System.Collections.Generic;
using PlayerRoles;

namespace DeshkaAutoDonate.Module.Models
{
    public class RoleData
    {
        public byte Id { get; set; } = 0;

        public string ConfigName { get; set; } = "";
        public Dictionary<RoleTypeId, int> ChangeByTimeRoles { get; set; } = new Dictionary<RoleTypeId, int>();
        public List<RoleTypeId> MtfChangeRoles { get; set; } = new List<RoleTypeId>();
        public List<RoleTypeId> ChaosChangeRoles { get; set; } = new List<RoleTypeId>();
        public Dictionary<RoleTypeId, List<ItemType>> SpawnItems { get; set; } = new Dictionary<RoleTypeId, List<ItemType>>();
        public bool AccessToFullServer { get; set; } = false;
        public bool Unrecoverable { get; set; } = false;
        public bool Queue { get; set; } = false;
        public bool SpecialQueue { get; set; } = false;
        public bool SpectatorFly { get; set; } = false;
    }
}