﻿namespace DeshkaAutoDonate.Module.Models
{
    public class CosmeticData
    {
        public string SchematicName { get; set; }
        public string VisualName { get; set; }
    }
}