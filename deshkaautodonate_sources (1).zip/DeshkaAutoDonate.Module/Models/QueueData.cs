namespace DeshkaAutoDonate.Module.Models
{
    public class QueueData
    {
        public int Id { get; set; }
        public byte RoleId { get; set; }
        public SimpleQueue<QueueElement> Queue { get; set; }

        public QueueElement Find(string userId)
        {
            return Queue.FirstOrDefault(q => q.UserId == userId);
        }
    }
}