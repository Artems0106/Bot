using PlayerRoles;

namespace DeshkaAutoDonate.Module.Models
{
    public class QueueElement
    {
        // на всякий случай пусть тут будет айди
        public int Id { get; set; }
        public string UserId { get; set; }
        public bool Special { get; set; }
        public RoleTypeId Role { get; set; } // only for special queue
    }
}