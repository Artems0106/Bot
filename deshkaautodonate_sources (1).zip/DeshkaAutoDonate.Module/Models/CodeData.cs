namespace DeshkaAutoDonate.Module.Models
{
    public class CodeData
    {
        public int Id { get; set; } = 0;
        public string Code { get; set; }
        public string Issuer { get; set; }
        public byte GroupId { get; set; }
        public int DonateDuration { get; set; }
    }
}