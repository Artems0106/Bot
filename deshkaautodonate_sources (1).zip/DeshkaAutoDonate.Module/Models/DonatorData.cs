﻿using System;
using System.Collections.Generic;
using PlayerRoles;

namespace DeshkaAutoDonate.Module.Models
{
    public class DonatorData
    {
        public int Id { get; set; } = 0;
    
        public ulong SteamId { get; set; }
    
        public byte GroupId { get; set; }
        
        public bool Suspended { get; set; }
        public DateTime SuspendExpires { get; set; }
        
        public bool UnrecoverableEnabled { get; set; }
        
        public List<string> Cosmetics { get; set; }

        public RoleTypeId MtfReplace { get; set; } = RoleTypeId.None;

        public RoleTypeId ChaosReplace { get; set; } = RoleTypeId.None;
        
        public bool RainbowNickname { get; set; }
        
        public DateTime IssuanceTime { get; set; }
        
        public string Issuer { get; set; }
    
        public DateTime ExpiringTime { get; set; }
    }
}