using System;
using System.Reflection;
using LabApi.Features.Wrappers;
using UserSettings.ServerSpecific;
using UnityEngine;

namespace DeshkaAutoDonate.Module.Patches
{
    internal static class VoiceMuteKeybind
    {
        private const int settingId = 9001;
        private static readonly KeyCode suggestedKey = KeyCode.G;
        private static readonly string settingLabel = "Мут спектаторов";
        private static readonly string settingDesc = "Переключить голос спектаторов в режиме полёта";

        private static bool _registered = false;
        private static Delegate _handler;

        public static void Register()
        {
            if (_registered) return;

            try
            {
                ServerSpecificSettingBase[] existing = ServerSpecificSettingsSync.DefinedSettings;

                var ourSettings = new ServerSpecificSettingBase[2];
                ourSettings[0] = new SSGroupHeader("Режим полёта", false, null);
                ourSettings[1] = new SSKeybindSetting(
                    settingId, settingLabel, suggestedKey,
                    false, false, settingDesc, byte.MaxValue);

                ServerSpecificSettingBase[] merged;
                if (existing != null && existing.Length > 0)
                {
                    merged = new ServerSpecificSettingBase[existing.Length + ourSettings.Length];
                    existing.CopyTo(merged, 0);
                    ourSettings.CopyTo(merged, existing.Length);
                }
                else
                {
                    merged = ourSettings;
                }

                ServerSpecificSettingsSync.DefinedSettings = merged;

                EventInfo evt = typeof(ServerSpecificSettingsSync).GetEvent("ServerOnSettingValueReceived",
                    BindingFlags.Public | BindingFlags.Static);
                if (evt != null)
                {
                    _handler = Delegate.CreateDelegate(evt.EventHandlerType,
                        typeof(VoiceMuteKeybind).GetMethod("OnSettingReceived",
                            BindingFlags.NonPublic | BindingFlags.Static));
                    evt.AddEventHandler(null, _handler);
                }

                _registered = true;
                Module.Instance?.Logger?.Info("[VoiceMuteKeybind] Registered (ID=" + settingId + ", total=" + merged.Length + ")");
            }
            catch (Exception ex)
            {
                Module.Instance?.Logger?.Error("[VoiceMuteKeybind] Register: " + ex.Message);
            }
        }

        public static void Unregister()
        {
            if (!_registered) return;
            try
            {
                EventInfo evt = typeof(ServerSpecificSettingsSync).GetEvent("ServerOnSettingValueReceived",
                    BindingFlags.Public | BindingFlags.Static);
                if (evt != null && _handler != null)
                    evt.RemoveEventHandler(null, _handler);
            }
            catch { }
            _registered = false;
        }

        private static void OnSettingReceived(ReferenceHub hub, ServerSpecificSettingBase setting)
        {
            try
            {
                if (hub == null || setting == null) return;

                var keybind = setting as SSKeybindSetting;
                if (keybind == null) return;
                if (keybind.SettingId != settingId) return;
                if (!keybind.SyncIsPressed) return;

                Player player = Player.Get(hub);
                if (player == null || player.IsDestroyed) return;
                if (!SpectatorFly.IsEnabled(player)) return;

                bool nowUnmuted = SpectatorFly.ToggleMute(player);
                SpectatorFly.ShowHint(player, !nowUnmuted);
            }
            catch (Exception ex)
            {
                Module.Instance?.Logger?.Error("[VoiceMuteKeybind] OnSetting: " + ex.Message);
            }
        }
    }
}
