using System;
using LabApi.Events.Arguments.PlayerEvents;
using LabApi.Events.CustomHandlers;
using LabApi.Features.Wrappers;
using Mirror;
using PlayerRoles;
using VoiceChat;
using VoiceChat.Networking;

namespace DeshkaAutoDonate.Module.Patches
{
    internal sealed class VoiceRelayHandler : CustomEventsHandler
    {
        public override void OnPlayerSendingVoiceMessage(PlayerSendingVoiceMessageEventArgs ev)
        {
            if (ev.Player == null) return;

            bool isFly = SpectatorFly.IsEnabled(ev.Player);
            bool isSpec = ev.Player.Role == RoleTypeId.Spectator;

            if (!isFly && !isSpec) return;

            try
            {
                byte[] data = ev.Message.Data;
                int dataLen = ev.Message.DataLength;
                if (data == null || dataLen == 0) return;

                if (isFly)
                {
                    byte ctrlId = SpectatorFly.GetToyId(ev.Player.UserId);
                    if (ctrlId == 0)
                        return;

                    ev.IsAllowed = false;
                    var msg = new AudioMessage(ctrlId, data, dataLen);

                    foreach (Player p in Player.ReadyList)
                    {
                        if (p == ev.Player) continue;
                        bool spec = p.Role == RoleTypeId.Spectator;
                        bool fly = SpectatorFly.IsEnabled(p);
                        if (!spec && !fly) continue;
                        try { p.Connection.Send(msg); }
                        catch { }
                    }
                }
                else
                {
                    foreach (Player p in Player.ReadyList)
                    {
                        if (p == ev.Player) continue;
                        if (!SpectatorFly.IsEnabled(p)) continue;

                        byte flyCtrlId = SpectatorFly.GetToyId(p.UserId);
                        if (flyCtrlId == 0) continue;

                        try
                        {
                            var msg = new AudioMessage(flyCtrlId, data, dataLen);
                            p.Connection.Send(msg);
                        }
                        catch { }
                    }
                }
            }
            catch (System.Exception ex)
            {
                Module.Instance?.Logger?.Error("[VoiceRelay] " + ex.Message);
            }
        }
    }
}
