using System;
using System.Security.Cryptography;
using System.Text;

namespace DeshkaAutoDonate.Module
{
    public static class CodeGen
    {
        private const string Alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

        public static string GenerateCode()
        {
            const int groupCount = 4;
            const int groupLength = 4;
            const int totalLength = groupCount * groupLength;

            char[] chars = new char[totalLength];

            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                byte[] buffer = new byte[4];

                for (int i = 0; i < totalLength; i++)
                {
                    int idx;
                    do
                    {
                        rng.GetBytes(buffer);
                        idx = BitConverter.ToInt32(buffer, 0) & int.MaxValue;
                        idx %= Alphabet.Length;
                    } while (idx < 0 || idx >= Alphabet.Length);

                    chars[i] = Alphabet[idx];
                }
            }

            StringBuilder sb = new StringBuilder(totalLength + (groupCount - 1));
            for (int i = 0; i < groupCount; i++)
            {
                if (i > 0)
                    sb.Append('-');

                sb.Append(chars, i * groupLength, groupLength);
            }

            return sb.ToString();
        }
    }
}