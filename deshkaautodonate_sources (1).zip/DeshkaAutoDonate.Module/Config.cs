﻿using System.Collections.Generic;
using Deshka.API.Interfaces;
using DeshkaAutoDonate.Module.Models;

namespace DeshkaAutoDonate.Module
{
    public class Config : IModuleConfig
    {
        public bool IsEnabled { get; set; } = true;
        public bool Debug { get; set; } = false;

        public string WebSocketHost { get; set; } = "0.0.0.0";
        public int WebSocketPort { get; set; } = 8888;

        public List<CosmeticData> Cosmetics { get; set; } = new List<CosmeticData>();
    
        public List<RoleData> Roles { get; set; } = new List<RoleData>();

        public string FullKickMessage { get; set; } = "Начиная с донатной привилегии Маршал вы можете заходить на переполненный сервер";
    }
}