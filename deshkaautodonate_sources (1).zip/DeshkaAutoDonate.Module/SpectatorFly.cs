using System;
using System.Linq;
using Deshka.API.Helpers;
using HintServiceMeow.Core.Extension;
using HintServiceMeow.Core.Enum;
using HintServiceMeow.Core.Models.Hints;
using HintServiceMeow.Core.Utilities;
using InventorySystem.Items;
using LabApi.Events.Arguments.PlayerEvents;
using LabApi.Events.Arguments.Scp049Events;
using LabApi.Events.Arguments.Scp096Events;
using LabApi.Events.Arguments.Scp173Events;
using LabApi.Events.Arguments.Scp3114Events;
using LabApi.Events.Arguments.Scp914Events;
using LabApi.Events.Arguments.ServerEvents;
using LabApi.Features.Wrappers;
using MEC;
using System.Collections.Generic;
using Deshka.API.Other;
using PlayerRoles;
using PlayerRoles.FirstPersonControl;
using PlayerRoles.Spectating;
using UnityEngine;
using Mirror;

namespace DeshkaAutoDonate.Module
{
    public static class SpectatorFly
    {
        private static readonly Dictionary<string, Player> _enabled = new Dictionary<string, Player>();
        private static readonly HashSet<string> _muted = new HashSet<string>();
        private static CoroutineHandle _keepAlive;

        private static Dictionary<string, ToyInfo> _toys = new Dictionary<string, ToyInfo>();
        private static byte _nextId = 200;
        private static GameObject _toyPrefab;

        private class ToyInfo
        {
            public GameObject GameObject;
            public AdminToys.SpeakerToy Toy;
            public byte ControllerId;
        }

        private class PendingToy
        {
            public AdminToys.SpeakerToy Toy;
        }

        private static Dictionary<byte, PendingToy> _pending = new Dictionary<byte, PendingToy>();

        private const string muteHint = "deshka_voicemute";

        private static readonly Dictionary<Faction, List<RoleTypeId>> Roles = new Dictionary<Faction, List<RoleTypeId>>()
        {
            { Faction.FoundationStaff , new List<RoleTypeId> { RoleTypeId.NtfPrivate, RoleTypeId.NtfSergeant } },
            { Faction.FoundationEnemy , new List<RoleTypeId> { RoleTypeId.ChaosConscript, RoleTypeId.ChaosRifleman, RoleTypeId.ChaosMarauder } }
        };

        private static void Log(string msg)
        {
            try { Module.Instance?.Logger?.Info("[SpectatorFly] " + msg); } catch { }
        }

        private static void LogError(string msg)
        {
            try { Module.Instance?.Logger?.Error("[SpectatorFly] " + msg); } catch { }
        }

        private static void SetSpectatorHidden(Player player, bool hidden)
        {
            if (player?.ReferenceHub == null) return;
            SpectatableVisibilityManager.SetHidden(player.ReferenceHub, hidden);
        }

        private static void MakeInvisible(Player player)
        {
            if (player?.ReferenceHub == null) return;
            SetSpectatorHidden(player, true);
            try { player.ReferenceHub.playerEffectsController.EnableEffect<CustomPlayerEffects.Invisible>(0f, true); } catch { }
            try { player.ReferenceHub.playerEffectsController.EnableEffect<CustomPlayerEffects.Ghostly>(0f, true); } catch { }
        }

        private static void MakeVisible(Player player)
        {
            if (player?.ReferenceHub == null) return;
            SetSpectatorHidden(player, false);
            try { player.ReferenceHub.playerEffectsController.DisableEffect<CustomPlayerEffects.Invisible>(); } catch { }
            try { player.ReferenceHub.playerEffectsController.DisableEffect<CustomPlayerEffects.Ghostly>(); } catch { }
        }

        public static byte GetToyId(string userId)
        {
            ToyInfo entry;
            if (_toys.TryGetValue(userId, out entry) && entry.GameObject != null)
                return entry.ControllerId;
            return 0;
        }

        private static bool CreateToy(string userId, Player player)
        {
            try
            {
                if (_toys.ContainsKey(userId)) DestroyToy(userId);

                if (_toyPrefab == null)
                {
                    _toyPrefab = FindToy();
                }

                if (_toyPrefab == null)
                {
                    LogError("AdminToys.SpeakerToy prefab not found!");
                    return false;
                }

                Vector3 pos = player.ReferenceHub != null ? player.Position : Vector3.zero;
                GameObject instance = UnityEngine.Object.Instantiate(_toyPrefab, pos, Quaternion.identity);
                AdminToys.SpeakerToy toy = instance.GetComponent<AdminToys.SpeakerToy>();
                byte ctrlId = _nextId++;

                if (toy == null)
                {
                    LogError("AdminToys.SpeakerToy component not found on instantiated prefab");
                    UnityEngine.Object.Destroy(instance);
                    return false;
                }

                toy.NetworkControllerId = 0;
                toy.NetworkMinDistance = 1f;
                toy.NetworkMaxDistance = 1f;

                _pending[ctrlId] = new PendingToy { Toy = toy };
                toy.NetworkControllerId = ctrlId;

                NetworkServer.Spawn(instance);
                _toys[userId] = new ToyInfo { GameObject = instance, Toy = toy, ControllerId = ctrlId };
                Log("AdminToys.SpeakerToy created for " + player.Nickname + " ctrlId=" + ctrlId);
                return true;
            }
            catch (Exception ex)
            {
                LogError("CreateToy: " + ex.Message);
                return false;
            }
        }

        private static bool DestroyToy(string userId)
        {
            try
            {
                ToyInfo entry;
                if (!_toys.TryGetValue(userId, out entry)) return false;

                if (entry.GameObject != null)
                {
                    if (entry.GameObject.GetComponent<NetworkIdentity>() != null && NetworkServer.active)
                        NetworkServer.Destroy(entry.GameObject);
                    else
                        UnityEngine.Object.Destroy(entry.GameObject);
                }

                _toys.Remove(userId);
                return true;
            }
            catch (Exception ex)
            {
                LogError("DestroyToy: " + ex.Message);
                return false;
            }
        }

        private static void ApplyPending()
        {
            if (_pending.Count == 0) return;

            foreach (var kvp in _pending.ToList())
            {
                try
                {
                    var setup = kvp.Value;
                    setup.Toy.NetworkMaxDistance = 15f;
                    setup.Toy.NetworkMinDistance = 0f;
                    setup.Toy.NetworkIsSpatial = true;
                    setup.Toy.NetworkVolume = 1f;
                    _pending.Remove(kvp.Key);
                }
                catch { _pending.Remove(kvp.Key); }
            }
        }

        private static void UpdateToy()
        {
            ApplyPending();

            foreach (var kvp in _toys.ToList())
            {
                try
                {
                    if (kvp.Value.GameObject == null) { _toys.Remove(kvp.Key); continue; }

                    Player player;
                    if (!_enabled.TryGetValue(kvp.Key, out player) || player == null || player.ReferenceHub == null)
                    {
                        DestroyToy(kvp.Key);
                        continue;
                    }

                    kvp.Value.GameObject.transform.position = player.Position;
                }
                catch { }
            }
        }

        internal static void Cleanup()
        {
            foreach (var userId in _toys.Keys.ToList())
                DestroyToy(userId);
            _toys.Clear();
            _pending.Clear();
        }

        private static GameObject FindToy()
        {
            AdminToys.SpeakerToy[] allToys = UnityEngine.Resources.FindObjectsOfTypeAll<AdminToys.SpeakerToy>();
            GameObject found = null;

            foreach (AdminToys.SpeakerToy toy in allToys)
            {
                if (toy == null || toy.gameObject == null) continue;
                bool isPrefab = toy.gameObject.scene == null || string.IsNullOrEmpty(toy.gameObject.scene.name);
                if (isPrefab)
                {
                    found = toy.gameObject;
                    break;
                }
            }

            if (found == null)
                LogError("No AdminToys.SpeakerToy prefab found anywhere!");

            return found;
        }

        public static void ShowHint(Player player, bool isMuted)
        {
            if (player == null) return;
            try
            {
                string text = isMuted
                    ? "<color=#ff4444><size=30><b>\U0001f507 Голос спектаторов: ВЫКЛ</b></size></color>"
                    : "<color=#00ff00><size=30><b>\U0001f50a Голос спектаторов: ВКЛ</b></size></color>";

                PlayerDisplay display = PlayerDisplay.Get(player);
                if (display == null) return;

                try { display.RemoveHint(muteHint); } catch { }

                Hint hint = new Hint();
                hint.Id = muteHint;
                hint.Text = text;
                hint.Alignment = HintAlignment.Center;
                hint.YCoordinateAlign = HintVerticalAlign.Middle;
                hint.YCoordinate = 800;
                hint.FontSize = 30;

                display.ShowHint(hint, 1.2f);

            }
            catch (Exception ex)
            {
                LogError("ShowHint: " + ex.GetType().Name + " - " + ex.Message + " - " + (ex.InnerException != null ? ex.InnerException.Message : "no inner"));
            }
        }

        public static void ClearHint(Player player)
        {
            if (player == null) return;
            try
            {
                PlayerDisplay display = PlayerDisplay.Get(player);
                display.RemoveHint(muteHint);
            }
            catch { }
        }

        public static bool SwitchMode(Player player, out string response)
        {
            if (_enabled.ContainsKey(player.UserId))
            {
                _enabled.Remove(player.UserId);
                _muted.Remove(player.UserId);
                ClearHint(player);
                player.IsNoclipEnabled = false;
                player.IsGodModeEnabled = false;
                MakeVisible(player);
                DestroyToy(player.UserId);
                player.SetRole(RoleTypeId.Spectator, RoleChangeReason.RemoteAdmin, RoleSpawnFlags.None);
                response = "\u0412\u044b \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0432\u044b\u0448\u043b\u0438 \u0438\u0437 \u0440\u0435\u0436\u0438\u043c\u0430 \u043f\u043e\u043b\u0451\u0442\u0430";
                return true;
            }

            string userId = player.UserId;
            _enabled[userId] = player;
            player.SetRole(RoleTypeId.Tutorial, RoleChangeReason.RemoteAdmin, RoleSpawnFlags.None);

            Timing.CallDelayed(0.5f, () =>
            {
                Player freshPlayer = Player.Get(userId);
                if (freshPlayer == null) return;

                if (_enabled.ContainsKey(userId))
                    _enabled[userId] = freshPlayer;

                Ragdoll playerRagdoll = Ragdoll.List.FirstOrDefault(r => r.Nickname == freshPlayer.Nickname);
                if (playerRagdoll != null)
                    freshPlayer.Position = playerRagdoll.Position + Vector3.up;

                freshPlayer.IsGodModeEnabled = true;
                freshPlayer.IsNoclipEnabled = true;
                freshPlayer.AddItem(ItemType.Coin);
                MakeInvisible(freshPlayer);

                Timing.CallDelayed(0.3f, () =>
                {
                    Player p = Player.Get(userId);
                    if (p != null && _enabled.ContainsKey(userId))
                    {
                        _enabled[userId] = p;
                        CreateToy(userId, p);
                    }
                });
            });

            response = "\u0412\u044b \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u0432\u043e\u0448\u043b\u0438 \u0432 \u0440\u0435\u0436\u0438\u043c \u043f\u043e\u043b\u0451\u0442\u0430";
            return true;
        }

        internal static void StartKeepAlive()
        {
            _keepAlive = Timing.RunCoroutine(KeepAliveLoop());
        }

        internal static void StopKeepAlive()
        {
            if (_keepAlive.IsRunning)
                Timing.KillCoroutines(_keepAlive);
        }

        private static IEnumerator<float> KeepAliveLoop()
        {
            while (true)
            {
                yield return Timing.WaitForSeconds(0.1f);

                if (_enabled.Count == 0) continue;

                foreach (var kvp in _enabled.ToList())
                {
                    string userId = kvp.Key;
                    Player player = Player.Get(userId);

                    if (player == null || player.ReferenceHub == null || player.IsDestroyed)
                    {
                        _enabled.Remove(userId);
                        _muted.Remove(userId);
                        DestroyToy(userId);
                        continue;
                    }

                    _enabled[userId] = player;

                    SetSpectatorHidden(player, true);

                    try { player.ReferenceHub.playerEffectsController.EnableEffect<CustomPlayerEffects.Invisible>(0f, false); } catch { }
                    try { player.ReferenceHub.playerEffectsController.EnableEffect<CustomPlayerEffects.Ghostly>(0f, false); } catch { }
                }

                UpdateToy();
            }
        }

        public static bool IsEnabled(Player player) => player != null && _enabled.ContainsKey(player.UserId);
        public static bool IsMuted(Player player) => player != null && _muted.Contains(player.UserId);

        public static bool ToggleMute(Player player)
        {
            if (player == null) return false;
            bool wasMuted = _muted.Contains(player.UserId);
            if (wasMuted) _muted.Remove(player.UserId);
            else _muted.Add(player.UserId);
            return !wasMuted;
        }

        internal static void ForceDisable(Player player)
        {
            if (player == null) return;
            string userId = player.UserId;
            if (!_enabled.ContainsKey(userId)) return;

            _enabled.Remove(userId);
            _muted.Remove(userId);
            ClearHint(player);
            player.IsNoclipEnabled = false;
            player.IsGodModeEnabled = false;
            MakeVisible(player);
            DestroyToy(userId);
        }

        internal static void OnPickingUpItem(PlayerPickingUpItemEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnPickingUpScp330(PlayerPickingUpScp330EventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnPickingUpAmmo(PlayerPickingUpAmmoEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnDroppingItem(PlayerDroppingItemEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnDroppingAmmo(PlayerDroppingAmmoEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }

        internal static void OnFlippedCoin(PlayerFlippedCoinEventArgs ev)
        {
            if (ev.Player == null || !IsEnabled(ev.Player)) return;

            List<Player> alive = Player.List.Where(p => p.IsAlive && p != ev.Player).ToList();
            if (!alive.TryGetRandomItem(out Player random))
            {
                ev.Player.ShowHint("\u0416\u0438\u0432\u044b\u0445 \u0438\u0433\u0440\u043e\u043a\u043e\u0432 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e :<", 1.5f);
                return;
            }

            ev.Player.Position = random.Position + Vector3.up;
            ev.Player.ShowHint(string.Format("\u0412\u044b \u0431\u044b\u043b\u0438 \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u044b \u043a \u0438\u0433\u0440\u043e\u043a\u0443 {0}", random.Nickname));
        }

        internal static void OnHurting(PlayerHurtingEventArgs ev)
        {
            if (IsEnabled(ev.Player)) { ev.IsAllowed = false; return; }
            if (ev.Attacker != null && IsEnabled(ev.Attacker)) ev.IsAllowed = false;
        }

        internal static void OnLeft(PlayerLeftEventArgs ev)
        {
            if (!IsEnabled(ev.Player)) return;
            _enabled.Remove(ev.Player.UserId);
            _muted.Remove(ev.Player.UserId);
            ClearHint(ev.Player);
            DestroyToy(ev.Player.UserId);
        }

        internal static void OnTogglingNoclip(PlayerTogglingNoclipEventArgs ev) { if (!ev.IsAllowed) ev.IsAllowed = IsEnabled(ev.Player); }

        internal static void OnWaveRespawning(WaveRespawningEventArgs ev)
        {
            if (ev.Wave == null) return;
            if (ev.Wave.Faction != Faction.FoundationStaff && ev.Wave.Faction != Faction.FoundationEnemy) return;

            foreach (Player player in Player.List.Where(p => _enabled.ContainsKey(p.UserId)).ToList())
            {
                ev.Roles[player] = RandomWaveRole(ev.Wave.Faction);
                SwitchMode(player, out _);
            }
        }

        internal static void OnAddingTarget(Scp096AddingTargetEventArgs ev) { if (ev.Target != null && IsEnabled(ev.Target)) ev.IsAllowed = false; }
        internal static void OnAddingObserver(Scp173AddingObserverEventArgs ev) { if (ev.Target != null && IsEnabled(ev.Target)) ev.IsAllowed = false; }
        internal static void OnStrangleStarting(Scp3114StrangleStartingEventArgs ev) { if (ev.Target != null && IsEnabled(ev.Target)) ev.IsAllowed = false; }
        internal static void OnInteractingDoor(PlayerInteractingDoorEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnInteractingLocker(PlayerInteractingLockerEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnInteractingScp330(PlayerInteractingScp330EventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnInteractingWarheadLever(PlayerInteractingWarheadLeverEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnInteractingElevator(PlayerInteractingElevatorEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnInteractingGenerator(PlayerInteractingGeneratorEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnInteractingScp914(Scp914ActivatingEventArgs ev) { if (ev.Player != null && IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnUnlockingWarheadButton(PlayerUnlockingWarheadButtonEventArgs ev) { if (ev.Player != null && IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnInteractingShootingTarget(PlayerInteractingShootingTargetEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnUsingIntercom(PlayerUsingIntercomEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnTriggeringTesla(PlayerTriggeringTeslaEventArgs ev) { if (ev.Player != null && IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnUsingItem(PlayerUsingItemEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnThrowingItem(PlayerThrowingItemEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnPickingUpArmor(PlayerPickingUpArmorEventArgs ev) { if (IsEnabled(ev.Player)) ev.IsAllowed = false; }
        internal static void OnUnlockingGenerator(PlayerUnlockingGeneratorEventArgs ev) { if (ev.Player != null && IsEnabled(ev.Player)) ev.IsAllowed = false; }

        private static RoleTypeId RandomWaveRole(Faction waveFaction)
        {
            List<RoleTypeId> list = Roles[waveFaction];
            return list.GetRandomItem();
        }
    }
}
