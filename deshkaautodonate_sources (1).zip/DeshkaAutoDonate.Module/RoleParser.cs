using System.Linq;
using Deshka.API.Helpers;
using System;
using System.Collections.Generic;
using LabApi.Features.Extensions;
using PlayerRoles;

namespace DeshkaAutoDonate.Module
{
    public static class RoleParser
    {
        private static readonly Dictionary<string, RoleTypeId> RoleMap = new Dictionary<string, RoleTypeId>(StringComparer.OrdinalIgnoreCase);

        static RoleParser()
        {
            RoleMap.Add("173", RoleTypeId.Scp173);
            RoleMap.Add("scp-173", RoleTypeId.Scp173);
            RoleMap.Add("scp173", RoleTypeId.Scp173);
            RoleMap.Add("печенька", RoleTypeId.Scp173);
            RoleMap.Add("печень", RoleTypeId.Scp173);
            RoleMap.Add("статуя", RoleTypeId.Scp173);
            RoleMap.Add("peanut", RoleTypeId.Scp173);
            RoleMap.Add("106", RoleTypeId.Scp106);
            RoleMap.Add("scp-106", RoleTypeId.Scp106);
            RoleMap.Add("scp106", RoleTypeId.Scp106);
            RoleMap.Add("дед", RoleTypeId.Scp106);
            RoleMap.Add("старый", RoleTypeId.Scp106);
            RoleMap.Add("ларри", RoleTypeId.Scp106);
            RoleMap.Add("larry", RoleTypeId.Scp106);
            RoleMap.Add("049", RoleTypeId.Scp049);
            RoleMap.Add("scp-049", RoleTypeId.Scp049);
            RoleMap.Add("scp049", RoleTypeId.Scp049);
            RoleMap.Add("чумной", RoleTypeId.Scp049);
            RoleMap.Add("чумка", RoleTypeId.Scp049);
            RoleMap.Add("доктор", RoleTypeId.Scp049);
            RoleMap.Add("plague", RoleTypeId.Scp049);
            RoleMap.Add("doctor", RoleTypeId.Scp049);

            RoleMap.Add("079", RoleTypeId.Scp079);
            RoleMap.Add("scp-079", RoleTypeId.Scp079);
            RoleMap.Add("scp079", RoleTypeId.Scp079);
            RoleMap.Add("комп", RoleTypeId.Scp079);
            RoleMap.Add("пк", RoleTypeId.Scp079);
            RoleMap.Add("компьютер", RoleTypeId.Scp079);
            RoleMap.Add("pc", RoleTypeId.Scp079);
            RoleMap.Add("computer", RoleTypeId.Scp079);
            RoleMap.Add("096", RoleTypeId.Scp096);
            RoleMap.Add("scp-096", RoleTypeId.Scp096);
            RoleMap.Add("scp096", RoleTypeId.Scp096);
            RoleMap.Add("скромник", RoleTypeId.Scp096);
            RoleMap.Add("стесняшка", RoleTypeId.Scp096);
            RoleMap.Add("плакса", RoleTypeId.Scp096);
            RoleMap.Add("shyguy", RoleTypeId.Scp096);
            RoleMap.Add("cryguy", RoleTypeId.Scp096);
            RoleMap.Add("939", RoleTypeId.Scp939);
            RoleMap.Add("scp-939", RoleTypeId.Scp939);
            RoleMap.Add("scp939", RoleTypeId.Scp939);
            RoleMap.Add("собака", RoleTypeId.Scp939);
            RoleMap.Add("пёс", RoleTypeId.Scp939);
            RoleMap.Add("гавкалка", RoleTypeId.Scp939);
            RoleMap.Add("dog", RoleTypeId.Scp939);
            RoleMap.Add("withmanyvoices", RoleTypeId.Scp939);
            RoleMap.Add("3114", RoleTypeId.Scp3114);
            RoleMap.Add("scp-3114", RoleTypeId.Scp3114);
            RoleMap.Add("scp3114", RoleTypeId.Scp3114);
            RoleMap.Add("скелетик", RoleTypeId.Scp3114);
            RoleMap.Add("скелетон", RoleTypeId.Scp3114);
            RoleMap.Add("скелет", RoleTypeId.Scp3114);
            RoleMap.Add("skeleton", RoleTypeId.Scp3114);
            RoleMap.Add("ntfspecialist", RoleTypeId.NtfSpecialist);
            RoleMap.Add("ntfspec", RoleTypeId.NtfSpecialist);
            RoleMap.Add("специалист", RoleTypeId.NtfSpecialist);
            RoleMap.Add("спец", RoleTypeId.NtfSpecialist);
            RoleMap.Add("мог специалист", RoleTypeId.NtfSpecialist);
            RoleMap.Add("ntfsergeant", RoleTypeId.NtfSergeant);
            RoleMap.Add("ntfserg", RoleTypeId.NtfSergeant);
            RoleMap.Add("сержант", RoleTypeId.NtfSergeant);
            RoleMap.Add("серёжа", RoleTypeId.NtfSergeant);
            RoleMap.Add("мог сержант", RoleTypeId.NtfSergeant);
            RoleMap.Add("ntfcaptain", RoleTypeId.NtfCaptain);
            RoleMap.Add("ntfcapt", RoleTypeId.NtfCaptain);
            RoleMap.Add("капитан", RoleTypeId.NtfCaptain);
            RoleMap.Add("капт", RoleTypeId.NtfCaptain);
            RoleMap.Add("мог капитан", RoleTypeId.NtfCaptain);
            RoleMap.Add("ntfprivate", RoleTypeId.NtfPrivate);
            RoleMap.Add("ntfpriv", RoleTypeId.NtfPrivate);
            RoleMap.Add("рядовой", RoleTypeId.NtfPrivate);
            RoleMap.Add("рядов", RoleTypeId.NtfPrivate);
            RoleMap.Add("рядовоймог", RoleTypeId.NtfPrivate);
            RoleMap.Add("рядовой мог", RoleTypeId.NtfPrivate);
            RoleMap.Add("могрядовой", RoleTypeId.NtfPrivate);
            RoleMap.Add("chaosrepressor", RoleTypeId.ChaosRepressor);
            RoleMap.Add("репрессор", RoleTypeId.ChaosRepressor);
            RoleMap.Add("пулемётчик", RoleTypeId.ChaosRepressor);
            RoleMap.Add("репрессор хаоса", RoleTypeId.ChaosRepressor);
            RoleMap.Add("пулемётчик пх", RoleTypeId.ChaosRepressor);
            RoleMap.Add("chaosconscript", RoleTypeId.ChaosConscript);
            RoleMap.Add("новобранец", RoleTypeId.ChaosConscript);
            RoleMap.Add("мобилизованный", RoleTypeId.ChaosConscript);
            RoleMap.Add("мобилизированный", RoleTypeId.ChaosConscript);
            RoleMap.Add("новобранец пх", RoleTypeId.ChaosConscript);
            RoleMap.Add("chaosrifleman", RoleTypeId.ChaosRifleman);
            RoleMap.Add("стрелок", RoleTypeId.ChaosRifleman);
            RoleMap.Add("рядовой пх", RoleTypeId.ChaosRifleman);
            RoleMap.Add("автоматчик", RoleTypeId.ChaosRifleman);
            RoleMap.Add("автоматчик пх", RoleTypeId.ChaosRifleman);
            RoleMap.Add("chaosmarauder", RoleTypeId.ChaosMarauder);
            RoleMap.Add("марадёр", RoleTypeId.ChaosMarauder);
            RoleMap.Add("револьверщик", RoleTypeId.ChaosMarauder);
            RoleMap.Add("марадёр пх", RoleTypeId.ChaosMarauder);
            RoleMap.Add("classd", RoleTypeId.ClassD);
            RoleMap.Add("deshka", RoleTypeId.ClassD);
            RoleMap.Add("дешка", RoleTypeId.ClassD);
            RoleMap.Add("классд", RoleTypeId.ClassD);
            RoleMap.Add("класс д", RoleTypeId.ClassD);
            RoleMap.Add("scientist", RoleTypeId.Scientist);
            RoleMap.Add("учёный", RoleTypeId.Scientist);
            RoleMap.Add("в говне мочёный", RoleTypeId.Scientist);
            RoleMap.Add("очкарик", RoleTypeId.Scientist);
            RoleMap.Add("умный человек в очках", RoleTypeId.Scientist);
            RoleMap.Add("security", RoleTypeId.FacilityGuard);
            RoleMap.Add("facility guard", RoleTypeId.FacilityGuard);
            RoleMap.Add("охранник", RoleTypeId.FacilityGuard);
            RoleMap.Add("охранник комплекса", RoleTypeId.FacilityGuard);
            RoleMap.Add("охранник пятёрочки", RoleTypeId.FacilityGuard);
            RoleMap.Add("spectator", RoleTypeId.Spectator);
            RoleMap.Add("наблюдатель", RoleTypeId.Spectator);
            RoleMap.Add("хули зыришь", RoleTypeId.Spectator);
            RoleMap.Add("tutorial", RoleTypeId.Tutorial);
            RoleMap.Add("туториал", RoleTypeId.Tutorial);
            RoleMap.Add("обучение", RoleTypeId.Tutorial);
            RoleMap.Add("как скачать видеокарту", RoleTypeId.Tutorial);
        }        internal static readonly RoleTypeId[] ExcludedScps = { RoleTypeId.Scp0492 };

        internal static readonly List<RoleTypeId> Scps = RoleMap.Where(kvp => kvp.Value.IsScp())
            .Where(kvp => !ExcludedScps.Contains(kvp.Value))
            .Select(kvp => kvp.Value).ToList();
    
        public static RoleTypeId? Parse(string role, bool ignoreScp = false, bool ignoreHumans = false)
        {
            if (!RoleMap.TryGetValue(role, out RoleTypeId roleType))
                return null;

            bool isScp = roleType.IsScp();
        
            if (isScp && ignoreScp)
                return null;

            if (!isScp && ignoreHumans)
                return null;
        
            return roleType;
        }

        public static RoleTypeId RandomScp()
        {
            return Scps.GetRandomItem();
        }

        public static RoleTypeId RandomScpExcept(RoleTypeId exclude)
        {
            List<RoleTypeId> available = Scps.Where(s => s != exclude).ToList();
            return available.Count > 0 ? available.GetRandomItem() : Scps.GetRandomItem();
        }

        public static RoleTypeId RandomScpExcept(IEnumerable<RoleTypeId> excludes)
        {
            HashSet<RoleTypeId> excludeSet = new HashSet<RoleTypeId>(excludes);
            List<RoleTypeId> available = Scps.Where(s => !excludeSet.Contains(s)).ToList();
            return available.Count > 0 ? available.GetRandomItem() : Scps.GetRandomItem();
        }
    }
}
