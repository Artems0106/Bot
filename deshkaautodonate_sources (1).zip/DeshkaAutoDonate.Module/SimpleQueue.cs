using System;
using System.Collections.Generic;

namespace DeshkaAutoDonate.Module
{
    public sealed class SimpleQueue<T>
    {
        private List<T> _buffer = new List<T>();

        private int _head;

        private int _count;

        public int Count => _count;

        public bool IsEmpty => _count == 0;

        public void Enqueue(T item)
        {
            if (_head + _count == _buffer.Count)
                _buffer.Add(item);
            else
                _buffer[_head + _count] = item;

            _count++;
        }

        public T Dequeue()
        {
            if (_count == 0)
                throw new InvalidOperationException("Queue is empty");

            T value = _buffer[_head];
            _buffer[_head] = default(T);
            _head++;
            _count--;

            if (_head > 64 && _head * 2 > _buffer.Count)
            {
                _buffer.RemoveRange(0, _head);
                _head = 0;
            }

            return value;
        }

        public T Peek()
        {
            if (_count == 0)
                throw new InvalidOperationException("Queue is empty");

            return _buffer[_head];
        }

        public T LastOrDefault()
        {
            if (_count == 0)
                return default(T);

            return _buffer[_head + _count - 1];
        }
        
        public T FirstOrDefault(Func<T, bool> predicate)
        {
            if (_count == 0)
                return default(T);

            int end = _head + _count;
            for (int i = _head; i < end; i++)
            {
                T value = _buffer[i];
                if (predicate(value))
                    return value;
            }

            return default(T);
        }

        public List<T> ToList()
        {
            List<T> result = new List<T>(_count);
            int end = _head + _count;
            for (int i = _head; i < end; i++)
            {
                result.Add(_buffer[i]);
            }
            return result;
        }

        public void Clear()
        {
            _buffer.Clear();
            _head = 0;
            _count = 0;
        }
    }
}
