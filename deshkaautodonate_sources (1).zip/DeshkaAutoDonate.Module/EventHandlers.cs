using DeshkaAutoDonate.Module.Patches;
using Deshka.API.Helpers;
using Deshka.API.Interfaces;
using DeshkaAutoDonate.Module.Models;
using InventorySystem.Items;
using LabApi.Events.Arguments.PlayerEvents;
using LabApi.Events.Arguments.Scp049Events;
using LabApi.Events.Arguments.Scp914Events;
using LabApi.Events.Handlers;
using LabApi.Events.CustomHandlers;
using LabApi.Features.Wrappers;
using MEC;
using System;
using System.Collections.Generic;
using System.Linq;
using LabApi.Features.Extensions;
using PlayerRoles;

namespace DeshkaAutoDonate.Module
{
    public static class EventHandlers
    {
        private static VoiceRelayHandler _voiceRelayHandler;

        public static void RegisterHandlers()
        {
            PlayerEvents.PreAuthenticating += OnPreAuth;
            PlayerEvents.Joined += OnJoined;
            PlayerEvents.Left += SpectatorFly.OnLeft;
            PlayerEvents.ChangingRole += OnChangingRole;
            PlayerEvents.ChangedRole += OnChangedRole;
            PlayerEvents.PickingUpItem += SpectatorFly.OnPickingUpItem;
            PlayerEvents.PickingUpScp330 += SpectatorFly.OnPickingUpScp330;
            PlayerEvents.PickingUpAmmo += SpectatorFly.OnPickingUpAmmo;
            PlayerEvents.PickingUpArmor += SpectatorFly.OnPickingUpArmor;
            PlayerEvents.DroppingItem += SpectatorFly.OnDroppingItem;
            PlayerEvents.DroppingAmmo += SpectatorFly.OnDroppingAmmo;
            PlayerEvents.FlippedCoin += SpectatorFly.OnFlippedCoin;
            PlayerEvents.Hurting += SpectatorFly.OnHurting;
            PlayerEvents.TogglingNoclip += SpectatorFly.OnTogglingNoclip;
            PlayerEvents.InteractingDoor += SpectatorFly.OnInteractingDoor;
            PlayerEvents.InteractingLocker += SpectatorFly.OnInteractingLocker;
            PlayerEvents.InteractingScp330 += SpectatorFly.OnInteractingScp330;
            PlayerEvents.InteractingWarheadLever += SpectatorFly.OnInteractingWarheadLever;
            PlayerEvents.InteractingElevator += SpectatorFly.OnInteractingElevator;
            PlayerEvents.InteractingGenerator += SpectatorFly.OnInteractingGenerator;
            PlayerEvents.InteractingShootingTarget += SpectatorFly.OnInteractingShootingTarget;
            PlayerEvents.UsingIntercom += SpectatorFly.OnUsingIntercom;
            PlayerEvents.UsingItem += SpectatorFly.OnUsingItem;
            PlayerEvents.ThrowingItem += SpectatorFly.OnThrowingItem;
            PlayerEvents.UnlockingWarheadButton += SpectatorFly.OnUnlockingWarheadButton;
            PlayerEvents.TriggeringTesla += SpectatorFly.OnTriggeringTesla;
            PlayerEvents.UnlockingGenerator += SpectatorFly.OnUnlockingGenerator;
            ServerEvents.RoundStarted += OnRoundStarted;
            ServerEvents.WaveRespawning += SpectatorFly.OnWaveRespawning;
            Scp049Events.StartingResurrection += OnStartingResurrection;
            Scp096Events.AddingTarget += SpectatorFly.OnAddingTarget;
            Scp173Events.AddingObserver += SpectatorFly.OnAddingObserver;
            Scp3114Events.StrangleStarting += SpectatorFly.OnStrangleStarting;
            Scp914Events.Activating += SpectatorFly.OnInteractingScp914;
            SpectatorFly.StartKeepAlive();

            _voiceRelayHandler = new VoiceRelayHandler();
            CustomHandlersManager.RegisterEventsHandler(_voiceRelayHandler);

            MEC.Timing.CallDelayed(2f, () => VoiceMuteKeybind.Register());
        }

        public static void UnregisterHandlers()
        {
            PlayerEvents.PreAuthenticating -= OnPreAuth;
            PlayerEvents.Joined -= OnJoined;
            PlayerEvents.Left -= SpectatorFly.OnLeft;
            PlayerEvents.ChangingRole -= OnChangingRole;
            PlayerEvents.ChangedRole -= OnChangedRole;
            PlayerEvents.PickingUpItem -= SpectatorFly.OnPickingUpItem;
            PlayerEvents.PickingUpScp330 -= SpectatorFly.OnPickingUpScp330;
            PlayerEvents.PickingUpAmmo -= SpectatorFly.OnPickingUpAmmo;
            PlayerEvents.PickingUpArmor -= SpectatorFly.OnPickingUpArmor;
            PlayerEvents.DroppingItem -= SpectatorFly.OnDroppingItem;
            PlayerEvents.DroppingAmmo -= SpectatorFly.OnDroppingAmmo;
            PlayerEvents.FlippedCoin -= SpectatorFly.OnFlippedCoin;
            PlayerEvents.Hurting -= SpectatorFly.OnHurting;
            PlayerEvents.TogglingNoclip -= SpectatorFly.OnTogglingNoclip;
            PlayerEvents.InteractingDoor -= SpectatorFly.OnInteractingDoor;
            PlayerEvents.InteractingLocker -= SpectatorFly.OnInteractingLocker;
            PlayerEvents.InteractingScp330 -= SpectatorFly.OnInteractingScp330;
            PlayerEvents.InteractingWarheadLever -= SpectatorFly.OnInteractingWarheadLever;
            PlayerEvents.InteractingElevator -= SpectatorFly.OnInteractingElevator;
            PlayerEvents.InteractingGenerator -= SpectatorFly.OnInteractingGenerator;
            PlayerEvents.InteractingShootingTarget -= SpectatorFly.OnInteractingShootingTarget;
            PlayerEvents.UsingIntercom -= SpectatorFly.OnUsingIntercom;
            PlayerEvents.UsingItem -= SpectatorFly.OnUsingItem;
            PlayerEvents.ThrowingItem -= SpectatorFly.OnThrowingItem;
            PlayerEvents.UnlockingWarheadButton -= SpectatorFly.OnUnlockingWarheadButton;
            PlayerEvents.TriggeringTesla -= SpectatorFly.OnTriggeringTesla;
            PlayerEvents.UnlockingGenerator -= SpectatorFly.OnUnlockingGenerator;
            ServerEvents.RoundStarted -= OnRoundStarted;
            ServerEvents.WaveRespawning -= SpectatorFly.OnWaveRespawning;
            Scp049Events.StartingResurrection -= OnStartingResurrection;
            Scp096Events.AddingTarget -= SpectatorFly.OnAddingTarget;
            Scp173Events.AddingObserver -= SpectatorFly.OnAddingObserver;
            Scp3114Events.StrangleStarting -= SpectatorFly.OnStrangleStarting;
            Scp914Events.Activating -= SpectatorFly.OnInteractingScp914;
            SpectatorFly.StopKeepAlive();

            if (_voiceRelayHandler != null)
            {
                CustomHandlersManager.UnregisterEventsHandler(_voiceRelayHandler);
                _voiceRelayHandler = null;
            }

            VoiceMuteKeybind.Unregister();
        }

        private static void OnPreAuth(PlayerPreAuthenticatingEventArgs ev)
        {
            if (ev.CanJoin) return;
            if (ev.Flags.HasFlag(CentralAuthPreauthFlags.GloballyBanned)) return;

            DonatorData donator = Module.Load(ev.UserId);

            if (donator == null)
            {
                Config config = Module.Instance.Config;
                if (config != null)
                    ev.RejectCustom(config.FullKickMessage);
                return;
            }

            RoleData data = Module.GetRoleById(donator.GroupId);
            ev.CanJoin = data.AccessToFullServer;
            ev.IsAllowed = data.AccessToFullServer;
        }

        private static void OnJoined(PlayerJoinedEventArgs ev)
        {
            Timing.CallDelayed(1.5f, () =>
            {
                if (ev.Player.ReferenceHub.serverRoles.Group != null) return;

                string userId = ev.Player.UserId;
                DonatorData donData = Module.Load(userId);
                if (donData == null) return;

                TimeSpan expiringSpan = donData.ExpiringTime - DateTime.UtcNow;

                if (expiringSpan.Days <= 7)
                    ev.Player.SendBroadcast("\u0412\u043d\u0438\u043c\u0430\u043d\u0438\u0435, \u0432\u0430\u0448\u0430 \u0434\u043e\u043d\u0430\u0442 \u043f\u0440\u0438\u0432\u0435\u043b\u0435\u0433\u0438\u044f \u0438\u0441\u0442\u0435\u043a\u0430\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 " + expiringSpan.Days + " \u0434\u043d\u0435\u0439", 15, Broadcast.BroadcastFlags.Normal, true);

                UserGroup group = ServerStatic.PermissionsHandler.GetGroup(Module.GetRoleById(donData.GroupId).ConfigName);
                if (group != null)
                    ev.Player.ReferenceHub.serverRoles.SetGroup(group);
            });
        }

        private static void OnChangingRole(PlayerChangingRoleEventArgs ev)
        {
            if (!ev.IsAllowed) return;

            if (ev.ChangeReason == RoleChangeReason.RemoteAdmin && ev.NewRole.IsDead())
                ev.Player.ClearItems();

            if (ev.ChangeReason == RoleChangeReason.RoundStart)
            {
                if (!Module.QueueProcessed)
                {
                    ProcessQueue();
                    Module.QueueProcessed = true;
                }

                if (Module.ReservedScps.Count == 0) return;

                RoleTypeId newRole = ev.NewRole;
                if (!newRole.IsScp()) return;

                bool isDonator = false;
                foreach (var kvp in Module.ReservedScps)
                {
                    if (kvp.Value == ev.Player.UserId)
                    {
                        isDonator = true;
                        break;
                    }
                }

                if (isDonator) return;

                bool isReserved = Module.ReservedScps.ContainsKey(newRole);
                bool alreadyTaken = Module.RoundStartAssignedScps.Contains(newRole);

                if (isReserved || alreadyTaken)
                {
                    List<RoleTypeId> available = RoleParser.Scps
                        .Where(s => !Module.ReservedScps.ContainsKey(s)
                                 && !Module.RoundStartAssignedScps.Contains(s))
                        .ToList();

                    if (available.Count > 0)
                    {
                        RoleTypeId replacementScp = available[new System.Random().Next(available.Count)];
                        ev.NewRole = replacementScp;
                        Module.RoundStartAssignedScps.Add(replacementScp);
                    }
                    else
                    {
                        RoleTypeId[] humanRoles = {
                            RoleTypeId.ClassD,
                            RoleTypeId.Scientist,
                            RoleTypeId.FacilityGuard
                        };
                        ev.NewRole = humanRoles[new System.Random().Next(humanRoles.Length)];
                    }
                    return;
                }

                Module.RoundStartAssignedScps.Add(newRole);
                return;
            }

            if (ev.ChangeReason != RoleChangeReason.Respawn && ev.ChangeReason != RoleChangeReason.RespawnMiniwave)
                return;

            DonatorData data = Module.Load(ev.Player.UserId);
            if (data == null) return;

            Faction faction = ev.NewRole.GetFaction();

            switch (faction)
            {
                case Faction.FoundationStaff:
                    if (data.MtfReplace == RoleTypeId.None) return;
                    ev.NewRole = data.MtfReplace;
                    return;
                case Faction.FoundationEnemy:
                    if (data.ChaosReplace == RoleTypeId.None) return;
                    ev.NewRole = data.ChaosReplace;
                    return;
                default:
                    return;
            }
        }

        private static void ProcessQueue()
        {
            Module.ReservedScps.Clear();
            Module.RoundStartAssignedScps.Clear();

            List<RoleData> datas = Module.GetRoles();

            foreach (RoleData data in datas)
            {
                if (!data.Queue) continue;

                QueueData queueData = Module.Load(data.Id);
                if (queueData == null || queueData.Queue.Count == 0) continue;

                QueueElement element = queueData.Queue.Dequeue();
                Module.Update(queueData);

                Player curPlayer = Player.Get(element.UserId);
                if (curPlayer == null) continue;

                RoleTypeId role;

                if (element.Special && element.Role != RoleTypeId.None)
                    role = element.Role;
                else
                    role = RoleParser.RandomScp();

                Module.ReservedScps[role] = element.UserId;
                return;
            }
        }

        private static void OnRoundStarted()
        {
            SpectatorFly.Cleanup();
            Module.LastRoundScpDonators = new HashSet<string>(Module.CurrentRoundScpDonators);
            Module.CurrentRoundScpDonators.Clear();

            Timing.CallDelayed(0.5f, () =>
            {
                foreach (var kvp in Module.ReservedScps)
                {
                    RoleTypeId scpRole = kvp.Key;
                    string donatorId = kvp.Value;

                    Player donator = Player.Get(donatorId);
                    if (donator == null) continue;

                    if (donator.Role != scpRole)
                        donator.SetRole(scpRole, RoleChangeReason.RemoteAdmin);

                    Module.CurrentRoundScpDonators.Add(donatorId);
                    donator.SendBroadcast("\u041f\u043e\u0437\u0434\u0440\u0430\u0432\u043b\u044f\u0435\u043c! \u041d\u0430\u0441\u0442\u0430\u043b\u0430 \u0432\u0430\u0448\u0430 \u043e\u0447\u0435\u0440\u0435\u0434\u044c \u0434\u043b\u044f \u0441\u043f\u0430\u0432\u043d\u0430", 10);
                }

                Module.ReservedScps.Clear();
                Module.QueueProcessed = false;
                Module.RoundStartAssignedScps.Clear();
            });
        }

        private static void OnChangedRole(PlayerChangedRoleEventArgs ev)
        {
            if (ev.Player == null) return;

            if (SpectatorFly.IsEnabled(ev.Player) && ev.NewRole.RoleTypeId != RoleTypeId.Tutorial)
            {
                SpectatorFly.ForceDisable(ev.Player);
                return;
            }

            if (ev.NewRole.RoleTypeId != RoleTypeId.ClassD
                && ev.NewRole.RoleTypeId != RoleTypeId.Scientist
                && ev.NewRole.RoleTypeId != RoleTypeId.FacilityGuard)
                return;

            DonatorData donData = Module.Load(ev.Player.UserId);
            if (donData == null) return;

            RoleData roleData = Module.GetRoleById(donData.GroupId);
            if (!roleData.SpawnItems.TryGetValue(ev.NewRole.RoleTypeId, out List<ItemType> items)) return;

            ItemType randomItem = items.GetRandomItem();

            if (randomItem.ToString().StartsWith("ammo", StringComparison.CurrentCultureIgnoreCase))
            {
                ev.Player.AddAmmo(randomItem, 50);
                return;
            }

            ev.Player.AddItem(randomItem, ItemAddReason.StartingItem);
        }

        private static void OnStartingResurrection(Scp049StartingResurrectionEventArgs ev)
        {
            if (ev.Target == null) return;

            DonatorData donatorData = Module.Load(ev.Target.UserId);
            if (donatorData == null || !donatorData.UnrecoverableEnabled) return;

            ev.CanResurrect = false;
            ev.IsAllowed = false;
        }
    }
}
